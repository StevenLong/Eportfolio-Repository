// Empty Lab Exam 2 template
// Program Id - Name - Description here

import java.util.Scanner;

public class LastNameFirstNameLabEx2
{
    public static void main(String[] args)
    {
		// File Objects/Variables

		// Record Layout

		// Other Variables

		// Initailise variables

		// Screen and Report Header

		// Main file Input until EOF

		// Output Footer details to Screen and Report

		// Close file

    }  // main

} // LastNameFirstNameLabEx2