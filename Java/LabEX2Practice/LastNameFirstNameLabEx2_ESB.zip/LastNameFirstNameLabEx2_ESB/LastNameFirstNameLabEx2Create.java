// Program Id - Name - Description here

import java.util.Scanner;

public class LastNameFirstNameLabEx2Create
{
    public static void main(String[] args)
    {
		// File Objects/Variables

		// Main while Input until Quit entered
		   // using Initial/Subsequent read approach
		   // with Input and Message Dialogs

		   // File Output

		// Close files

    }  // main

} // LastNameFirstNameLabEx2Create