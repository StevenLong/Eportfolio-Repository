// LastNameFirstNameLabEx3 - your name here
// your description here

import java.util.Scanner;
//import

public class LastNameFirstNameLabEx3
{
    public static void main(String[] args) // throws
    {
		// 0) Constants/File objects/File Variables/Arrays/Other Variables

		// 1) File 1 Input init/while/subsequent read Populate & Output arrays

		// 2) File 2 Input init/while/subsequent read & Output

		// 3) do/while single row Output with nested do/while validation

		// 4) File 2 Reprocessed - Input init/while/subsequent read & Output
		      // Search - sucessful/unsucessful processing

		// 5) File Output from arrays
			  // Close Files

    }  // main

} // LastNameFirstNameLabEx3

