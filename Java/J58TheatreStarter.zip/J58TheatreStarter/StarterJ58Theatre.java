// J58TheatreStarter - Gerry Agnew
// Theatre Bookings and Cancellations
// Using seq text file storage and 2 dim char array processing

// Find (F5) 5 occurences of "fix" and correct accordingly

import java.util.Scanner;
// import fix

public class StarterJ58Theatre
{
	public static void main(String[] args) // throws fix
	{
		// Constants
		final int ROWS = 15, SEATS = 12;

		// Input file
		// Scanner inTheatreFile = fix

		// Output file with updated data
		// PrintWriter outTheatreFile = fix

		// Declarations - Variables & Arrays

		// char seatPlan[][] = fix

		// Other Variables
		Scanner console = new Scanner (System.in);
		int row, seat, rowNo, seatNo, bookingTot, cancelTot;
		char option;

		//Initialise Totals

		// Populate theatre 2 dim array from text file
		// fors nested row / seat fix

		// Initial read
		System.out.print("\nEnter B(ooking), C(ancel) or eXit: ");

		// Make/Cancel Booking loop until x/X encountered

		// Main while
		//
		// switch (option)
		//	b/B Booking - get rowNo and seatNo
		// 		Make booking Or Already booked

		// 	same c/C Cancel booking or Not booked

		// 	x/X eXit

		// 	default - Invalid option

		// Subsequent read
		// System.out.print("\nEnter B(ooking), C(ancel) or eXit: ");

		// Output Theatre Seat Plan

		// Output Theatre Seat Plan to text file
		// fors nested seat and seat

		// Close files

	}// main

}// class