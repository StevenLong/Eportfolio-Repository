// LastNameFirstNameLabEx3 - your name here
// your program description here

import java.util.Scanner;
// file import

public class LastNameFirstNameLabEx3
{
    public static void main(String[] args) // throws
    {
		// 1) Constants; File objects; File Variables; 1/2 dim Arrays; Other Variables
		//    Initialised; Output Headers

		// 2) while/Master File Input/Populate Arrays/Arrays Output

		// 3) while/Tx File Input/no Arrays/Tx File Variables Output

		// 4) outer while/Tx File Input/Re-processed
		//    inner while search unsuccessful: Output Mismatched/Rejected Report
		//    otherwise, search successful: update 2 dim Array with Tx values

		// 5) for(s)/Output Arrays to verify updated contents

		// 6/ outer while/Enter string/until sentinel encountered
		//    inner while search unsuccessful: Not Found Error Message
		//    Otherwise, search successful: prompt/apply changes with do..while validation

		// 7) for(s)/Save Updated Arrays to a new Output file
		//    Remember the sentinel & close files

    }  // main

} // LastNameFirstNameLabEx3