// Gerry Agnew

public class Lorry
{

} // Lorry