// Insurer inner class

public class Insurer
{

} // Insurer