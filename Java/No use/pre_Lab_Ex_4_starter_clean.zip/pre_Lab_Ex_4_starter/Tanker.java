// Tanker sub class

public class Tanker
{

} // Tanker