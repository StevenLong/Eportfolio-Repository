// TestShip1 driver class with simple object instances

public class TestShip1
{
    public static void main (String[] args)
    {
		System.out.printf("      %-4s %-12s %9s %-14s %-12s  \n",
						"Ship", "Name of Ship", "Weight", "Insurer", "Value");
		System.out.println("===========================================================================");

		// Insurer("Murphy Ins", 100000.99);
		// Insurer("Agnew Ins", 123456.99);

		// CargoShip(1000, "Red ship 1", 30000.10);
		// Insurer("Agnew Ins", 12345.55);

		// CargoShip(2000, "Green ship 2", 9999.99, "Murphy Ins", 9789.20);

		// CargoShip(2500, "Navy ship 3", 7777.99);
		// Insurer("Wally Ins", 22222.20);

		// Container (3000, "Blue con 1", 9999.99);
		// Insurer("Ins 34", 3434.34);

		// Container(4000, "Yellow con 2", 997899.99, "Agnew Ins", 12345.88);

		// RoRo (5000, "Grey ror 1", 1239.99);
		// RoRo (345, 678);
		// Insurer("Reilly Ins", 3434.34);

		// RoRo (6000, "White ror 2", 997899.99, "Agnew Ins", 12345.88, 11, 22);

		// Tanker (7000, "Purple tnk 1", 12939.99);
		// Tanker (99999);
		// Insurer("Ins 34", 3434.34);

		// Tanker (8000, "Black tnk 2", 997899.99, "Agnew Ins", 12345.88, 4567);

    }// main

} // TestShip1