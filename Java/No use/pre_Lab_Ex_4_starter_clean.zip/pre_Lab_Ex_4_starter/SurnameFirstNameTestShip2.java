// TestShip2 driver class using array of Cargo Ship objects

public class TestShip2
{
    public static void main (String[] args)
    {
		final int MAX_SHIPS = 9;

		System.out.printf("      %8s %-12s %9s %-14s %-12s  \n",
						"Ship", "Name of Ship", "Weight", "Insurer", "Value");
		System.out.println("===========================================================================");

    }

} // TestShip2