// CargoShip super class

public class CargoShip
{

} // CargoShip